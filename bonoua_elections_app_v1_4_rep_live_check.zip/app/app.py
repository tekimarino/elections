import csv
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any

from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify

from werkzeug.security import generate_password_hash

from .utils.storage import load_json, save_json, touch_last_update, DATA_DIR
from .utils.auth import authenticate, current_user, login_required, role_required
from .utils.calc import compute_summary

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"
UPLOAD_DIR = STATIC_DIR / "uploads"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

def create_app() -> Flask:
    app = Flask(__name__, template_folder="templates", static_folder="static")
    app.secret_key = os.environ.get("SECRET_KEY", "dev-secret-change-me")

    _ensure_seed_data()

    @app.context_processor
    def inject_user():
        return {"current_user": current_user()}

    @app.get("/")
    def index():
        u = current_user()
        if not u:
            return redirect(url_for("login"))
        if u["role"] == "admin":
            return redirect(url_for("admin_dashboard"))
        if u["role"] == "rep":
            return redirect(url_for("rep_dashboard"))
        return redirect(url_for("public_results"))

    # -------------------------
    # Auth
    # -------------------------
    @app.route("/login", methods=["GET", "POST"])
    def login():
        if request.method == "POST":
            username = request.form.get("username", "").strip()
            password = request.form.get("password", "")
            u = authenticate(username, password)
            if u:
                session["username"] = u["username"]
                flash("Connexion réussie.", "success")
                nxt = request.args.get("next") or url_for("index")
                return redirect(nxt)
            flash("Identifiants invalides.", "danger")
        return render_template("login.html")

    @app.get("/logout")
    def logout():
        session.clear()
        flash("Déconnecté.", "info")
        return redirect(url_for("login"))

    # -------------------------
    # Public results (live)
    # -------------------------
    @app.get("/results")
    def public_results():
        election = load_json("election.json", default={})
        return render_template("public_results.html", election=election)

    @app.get("/api/results/summary")
    def api_results_summary():
        polling_stations = load_json("polling_stations.json", default=[])
        candidates = load_json("candidates.json", default=[])
        results = load_json("results.json", default={})
        meta = load_json("meta.json", default={})
        summary = compute_summary(polling_stations, candidates, results)
        summary["last_update_utc"] = meta.get("last_update_utc")
        return jsonify(summary)

    # -------------------------
    # Representative
    # -------------------------
    @app.get("/rep")
    @login_required
    @role_required("rep")
    def rep_dashboard():
        u = current_user()
        election = load_json("election.json", default={})
        candidates = load_json("candidates.json", default=[])
        polling_stations = load_json("polling_stations.json", default=[])
        results = load_json("results.json", default={})
        assigned_code = u.get("polling_station_code")

        station = next((s for s in polling_stations if s.get("code") == assigned_code), None)
        existing = results.get(assigned_code) if assigned_code else None

        return render_template(
            "rep_dashboard.html",
            election=election,
            candidates=candidates,
            station=station,
            existing=existing,
        )

    @app.post("/rep/submit")
    @login_required
    @role_required("rep")
    def rep_submit():
        u = current_user()
        assigned_code = u.get("polling_station_code")
        if not assigned_code:
            flash("Aucun bureau n’est affecté à votre compte.", "danger")
            return redirect(url_for("rep_dashboard"))

        polling_stations = load_json("polling_stations.json", default=[])
        station = next((s for s in polling_stations if s.get("code") == assigned_code), None)

        candidates = load_json("candidates.json", default=[])
        votes: Dict[str, int] = {}

        # validate votes are integers >= 0
        for c in candidates:
            cid = c["id"]
            raw = request.form.get(f"votes_{cid}", "0").strip()
            if raw == "":
                raw = "0"
            try:
                iv = int(raw)
            except Exception:
                flash("Les voix doivent être des entiers.", "danger")
                return redirect(url_for("rep_dashboard"))
            if iv < 0:
                flash("Les voix ne peuvent pas être négatives.", "danger")
                return redirect(url_for("rep_dashboard"))
            votes[cid] = iv

        total = sum(votes.values())
        if total == 0:
            flash("Impossible d’enregistrer un PV avec 0 voix partout.", "warning")
            return redirect(url_for("rep_dashboard"))

        # Control: total votes cannot exceed registered voters for this polling station
        # (user requirement: total voix d'un PV <= inscrits du bureau)
        if station:
            registered = _safe_int(station.get("registered"), default=0)
            if registered > 0 and total > registered:
                flash(
                    f"PV invalide : total des voix ({total}) supérieur au nombre d’inscrits du bureau ({registered}).",
                    "danger",
                )
                return redirect(url_for("rep_dashboard"))

        results = load_json("results.json", default={})
        now = datetime.now(timezone.utc).isoformat()

        results[assigned_code] = {
            "polling_station_code": assigned_code,
            "votes": votes,
            "total_votes": total,
            "status": "SUBMITTED",
            "submitted_by": u["username"],
            "submitted_at_utc": now,
            "validated_by": results.get(assigned_code, {}).get("validated_by"),
            "validated_at_utc": results.get(assigned_code, {}).get("validated_at_utc"),
        }

        save_json("results.json", results)
        touch_last_update()
        flash("Résultat enregistré. Merci !", "success")
        return redirect(url_for("rep_dashboard"))

    # -------------------------
    # Admin
    # -------------------------
    @app.get("/admin")
    @login_required
    @role_required("admin")
    def admin_dashboard():
        election = load_json("election.json", default={})
        polling_stations = load_json("polling_stations.json", default=[])
        candidates = load_json("candidates.json", default=[])
        results = load_json("results.json", default={})
        summary = compute_summary(polling_stations, candidates, results)
        return render_template("admin_dashboard.html", election=election, summary=summary)

    @app.route("/admin/candidates", methods=["GET", "POST"])
    @login_required
    @role_required("admin")
    def admin_candidates():
        candidates = load_json("candidates.json", default=[])

        if request.method == "POST":
            name = request.form.get("name", "").strip()
            party = request.form.get("party", "").strip()

            if not name:
                flash("Nom du candidat requis.", "danger")
                return redirect(url_for("admin_candidates"))

            photo_path = ""
            photo = request.files.get("photo")
            if photo and photo.filename:
                ext = os.path.splitext(photo.filename)[1].lower()
                if ext not in [".png", ".jpg", ".jpeg", ".webp"]:
                    flash("Format image non supporté (png/jpg/webp).", "danger")
                    return redirect(url_for("admin_candidates"))
                fname = f"cand_{int(datetime.utcnow().timestamp())}{ext}"
                dest = UPLOAD_DIR / fname
                photo.save(dest)
                photo_path = f"/static/uploads/{fname}"

            new_id = _next_id([c["id"] for c in candidates], prefix="C")
            candidates.append({"id": new_id, "name": name, "party": party, "photo": photo_path})
            save_json("candidates.json", candidates)
            flash("Candidat ajouté.", "success")
            return redirect(url_for("admin_candidates"))

        return render_template("admin_candidates.html", candidates=candidates)

    @app.route("/admin/candidates/<cid>/edit", methods=["GET", "POST"])
    @login_required
    @role_required("admin")
    def admin_candidate_edit(cid: str):
        candidates = load_json("candidates.json", default=[])
        cand = next((c for c in candidates if c.get("id") == cid), None)
        if not cand:
            flash("Candidat introuvable.", "danger")
            return redirect(url_for("admin_candidates"))

        if request.method == "POST":
            name = request.form.get("name", "").strip()
            party = request.form.get("party", "").strip()
            if not name:
                flash("Nom du candidat requis.", "danger")
                return redirect(url_for("admin_candidate_edit", cid=cid))

            # optional new photo
            photo = request.files.get("photo")
            if photo and photo.filename:
                ext = os.path.splitext(photo.filename)[1].lower()
                if ext not in [".png", ".jpg", ".jpeg", ".webp"]:
                    flash("Format image non supporté (png/jpg/webp).", "danger")
                    return redirect(url_for("admin_candidate_edit", cid=cid))
                fname = f"cand_{cid}_{int(datetime.utcnow().timestamp())}{ext}"
                dest = UPLOAD_DIR / fname
                photo.save(dest)
                cand["photo"] = f"/static/uploads/{fname}"

            cand["name"] = name
            cand["party"] = party
            save_json("candidates.json", candidates)
            touch_last_update()
            flash("Candidat modifié.", "success")
            return redirect(url_for("admin_candidates"))

        return render_template("admin_candidate_edit.html", cand=cand)

    @app.post("/admin/candidates/<cid>/delete")
    @login_required
    @role_required("admin")
    def admin_candidate_delete(cid: str):
        candidates = load_json("candidates.json", default=[])
        if not any(c.get("id") == cid for c in candidates):
            flash("Candidat introuvable.", "danger")
            return redirect(url_for("admin_candidates"))
        candidates = [c for c in candidates if c.get("id") != cid]
        save_json("candidates.json", candidates)

        # Clean votes in PVs
        results = load_json("results.json", default={})
        changed = False
        to_delete = []
        for code, r in results.items():
            votes = r.get("votes") or {}
            if cid in votes:
                votes.pop(cid, None)
                r["votes"] = votes
                r["total_votes"] = int(sum(int(v) for v in votes.values()))
                changed = True
                if r["total_votes"] <= 0:
                    to_delete.append(code)
        for code in to_delete:
            results.pop(code, None)
        if changed or to_delete:
            save_json("results.json", results)

        touch_last_update()
        flash("Candidat supprimé.", "success")
        return redirect(url_for("admin_candidates"))

    

    @app.route("/admin/voting-centers", methods=["GET", "POST"])
    @login_required
    @role_required("admin")
    def admin_voting_centers():
        centers = load_json("voting_centers.json", default=[])

        if request.method == "POST":
            mode = request.form.get("mode", "").strip()

            if mode == "import":
                f = request.files.get("csv_file")
                if not f or not f.filename:
                    flash("Veuillez choisir un fichier CSV.", "danger")
                    return redirect(url_for("admin_voting_centers"))

                decoded = f.stream.read().decode("utf-8", errors="ignore").splitlines()
                reader = csv.DictReader(decoded)

                required = {"commune", "centre_code", "centre_name", "nb_bureaux", "registered_total"}
                if not required.issubset(set(reader.fieldnames or [])):
                    flash("CSV invalide. Colonnes requises: " + ", ".join(sorted(required)), "danger")
                    return redirect(url_for("admin_voting_centers"))

                new_centers = []
                for row in reader:
                    code = (row.get("centre_code") or "").strip()
                    name = (row.get("centre_name") or "").strip()
                    commune = (row.get("commune") or "BONOUA").strip() or "BONOUA"
                    nb_bureaux = int((row.get("nb_bureaux") or "0").replace(" ", "") or 0)
                    reg_total = int((row.get("registered_total") or "0").replace(" ", "") or 0)

                    if not code or not name:
                        continue

                    new_centers.append({
                        "code": code.zfill(3),
                        "name": name,
                        "nb_bureaux": nb_bureaux,
                        "registered_total": reg_total,
                        "commune": commune
                    })

                save_json("voting_centers.json", new_centers)
                touch_last_update()
                flash(f"Import centres OK: {len(new_centers)} centre(s).", "success")
                return redirect(url_for("admin_voting_centers"))

        return render_template("admin_voting_centers.html", centers=centers)

    @app.route("/admin/voting-centers/<centre_code>/edit", methods=["GET", "POST"])
    @login_required
    @role_required("admin")
    def admin_voting_center_edit(centre_code: str):
        centers = load_json("voting_centers.json", default=[])
        stations = load_json("polling_stations.json", default=[])
        centre_code = (centre_code or "").strip().zfill(3)
        center = next((c for c in centers if (c.get("code") or "").zfill(3) == centre_code), None)
        if not center:
            flash("Centre introuvable.", "danger")
            return redirect(url_for("admin_voting_centers"))

        if request.method == "POST":
            new_code = (request.form.get("code") or centre_code).strip().zfill(3)
            new_name = (request.form.get("name") or "").strip()
            commune = (request.form.get("commune") or (center.get("commune") or "BONOUA")).strip() or "BONOUA"
            if not new_name:
                flash("Nom du centre requis.", "danger")
                return redirect(url_for("admin_voting_center_edit", centre_code=centre_code))

            # If code changed, cascade to polling stations + users + PV
            if new_code != centre_code:
                if any((c.get("code") or "").zfill(3) == new_code for c in centers):
                    flash("Ce code de centre existe déjà.", "danger")
                    return redirect(url_for("admin_voting_center_edit", centre_code=centre_code))

                # compute future station codes to avoid duplicates
                existing_codes = {s.get("code") for s in stations if s.get("centre_code") != centre_code}
                to_update = [s for s in stations if s.get("centre_code") == centre_code]
                future_codes = []
                for s in to_update:
                    bureau_code = (s.get("bureau_code") or "").strip() or "BV??"
                    future_codes.append(f"BONOUA-{new_code}-{bureau_code}")
                if len(future_codes) != len(set(future_codes)) or any(fc in existing_codes for fc in future_codes):
                    flash("Changement de code impossible: conflit de codes bureaux.", "danger")
                    return redirect(url_for("admin_voting_center_edit", centre_code=centre_code))

                # Apply cascade
                users = load_json("users.json", default=[])
                results = load_json("results.json", default={})
                for s in to_update:
                    old_ps_code = s.get("code")
                    bureau_code = (s.get("bureau_code") or "").strip() or "BV??"
                    new_ps_code = f"BONOUA-{new_code}-{bureau_code}"
                    s["centre_code"] = new_code
                    s["centre_name"] = new_name
                    s["code"] = new_ps_code
                    s["name"] = f"{new_code} - {new_name} / {bureau_code}"

                    # user assignments
                    for u in users:
                        if u.get("polling_station_code") == old_ps_code:
                            u["polling_station_code"] = new_ps_code

                    # PV keys
                    if old_ps_code and old_ps_code in results:
                        results[new_ps_code] = results.pop(old_ps_code)
                        results[new_ps_code]["polling_station_code"] = new_ps_code

                # Update center itself
                center["code"] = new_code
                centre_code = new_code
                save_json("users.json", users)
                save_json("results.json", results)
                save_json("polling_stations.json", stations)

            # Update name/commune and refresh stats
            center["name"] = new_name
            center["commune"] = commune
            centers = _recompute_center_stats(centers, stations)
            save_json("voting_centers.json", centers)
            touch_last_update()
            flash("Centre modifié.", "success")
            return redirect(url_for("admin_voting_centers"))

        # compute current totals for display
        centers = _recompute_center_stats(centers, stations)
        center = next((c for c in centers if (c.get("code") or "").zfill(3) == centre_code), center)
        return render_template("admin_voting_center_edit.html", center=center)

    @app.post("/admin/voting-centers/<centre_code>/delete")
    @login_required
    @role_required("admin")
    def admin_voting_center_delete(centre_code: str):
        centre_code = (centre_code or "").strip().zfill(3)
        centers = load_json("voting_centers.json", default=[])
        if not any((c.get("code") or "").zfill(3) == centre_code for c in centers):
            flash("Centre introuvable.", "danger")
            return redirect(url_for("admin_voting_centers"))

        stations = load_json("polling_stations.json", default=[])
        station_count = sum(1 for s in stations if (s.get("centre_code") or "").zfill(3) == centre_code)
        if station_count > 0:
            flash(
                f"Suppression interdite : ce centre contient {station_count} bureau(x). "
                "Supprimez d’abord les bureaux (ou changez leur centre) avant de supprimer le centre.",
                "danger",
            )
            return redirect(url_for("admin_voting_centers"))

        # Centre vide : suppression autorisée
        centers = [c for c in centers if (c.get("code") or "").zfill(3) != centre_code]
        if centers:
            centers = _recompute_center_stats(centers, stations)
        save_json("voting_centers.json", centers)

        touch_last_update()
        flash("Centre supprimé.", "success")
        return redirect(url_for("admin_voting_centers"))



    @app.route("/admin/polling-stations", methods=["GET", "POST"])
    @login_required
    @role_required("admin")
    def admin_polling_stations():
        stations = load_json("polling_stations.json", default=[])

        if request.method == "POST":
            mode = request.form.get("mode", "").strip()

            if mode == "import":
                f = request.files.get("csv_file")
                if not f or not f.filename:
                    flash("Veuillez choisir un fichier CSV.", "danger")
                    return redirect(url_for("admin_polling_stations"))

                decoded = f.stream.read().decode("utf-8", errors="ignore").splitlines()
                reader = csv.DictReader(decoded)

                required = {"polling_station_code", "centre_code", "centre_name", "bureau_code", "bureau_num", "registered"}
                if not required.issubset(set(reader.fieldnames or [])):
                    flash("CSV invalide. Colonnes requises: " + ", ".join(sorted(required)), "danger")
                    return redirect(url_for("admin_polling_stations"))

                new_stations = []
                for row in reader:
                    code = (row.get("polling_station_code") or "").strip()
                    centre_code = (row.get("centre_code") or "").strip().zfill(3)
                    centre_name = (row.get("centre_name") or "").strip()
                    bureau_code = (row.get("bureau_code") or "").strip() or None
                    registered = int((row.get("registered") or "0").replace(" ", "") or 0)

                    if not code or not centre_code:
                        continue

                    if not centre_name:
                        centre_name = centre_code

                    if not bureau_code:
                        # fallback from bureau_num
                        try:
                            bn = int((row.get("bureau_num") or "0").strip() or 0)
                            bureau_code = f"BV{bn:02d}" if bn else "BV??"
                        except Exception:
                            bureau_code = "BV??"

                    new_stations.append({
                        "code": code,
                        "name": f"{centre_code} - {centre_name} / {bureau_code}",
                        "centre_code": centre_code,
                        "centre_name": centre_name,
                        "bureau_code": bureau_code,
                        "registered": registered
                    })

                save_json("polling_stations.json", new_stations)
                # refresh center stats if centers exist
                centers = load_json("voting_centers.json", default=[])
                if centers:
                    centers = _recompute_center_stats(centers, new_stations)
                    save_json("voting_centers.json", centers)
                touch_last_update()
                flash(f"Import bureaux OK: {len(new_stations)} bureau(x).", "success")
                return redirect(url_for("admin_polling_stations"))

        return render_template("admin_polling_stations.html", stations=stations)

    @app.route("/admin/polling-stations/<ps_code>/edit", methods=["GET", "POST"])
    @login_required
    @role_required("admin")
    def admin_polling_station_edit(ps_code: str):
        stations = load_json("polling_stations.json", default=[])
        centers = load_json("voting_centers.json", default=[])
        station = next((s for s in stations if s.get("code") == ps_code), None)
        if not station:
            flash("Bureau introuvable.", "danger")
            return redirect(url_for("admin_polling_stations"))

        if request.method == "POST":
            centre_code = (request.form.get("centre_code") or station.get("centre_code") or "").strip().zfill(3)
            bureau_code = (request.form.get("bureau_code") or station.get("bureau_code") or "").strip() or "BV??"
            registered = _safe_int(request.form.get("registered"), default=int(station.get("registered") or 0))

            centre_name = next((c.get("name") for c in centers if (c.get("code") or "").zfill(3) == centre_code), station.get("centre_name") or centre_code)

            old_code = station.get("code")
            new_code = f"BONOUA-{centre_code}-{bureau_code}"

            if new_code != old_code and any(s.get("code") == new_code for s in stations):
                flash("Impossible: ce code de bureau existe déjà.", "danger")
                return redirect(url_for("admin_polling_station_edit", ps_code=ps_code))

            # Update station
            station["centre_code"] = centre_code
            station["centre_name"] = centre_name
            station["bureau_code"] = bureau_code
            station["registered"] = registered
            station["name"] = f"{centre_code} - {centre_name} / {bureau_code}"
            station["code"] = new_code

            # Cascade updates if code changed
            if new_code != old_code:
                users = load_json("users.json", default=[])
                results = load_json("results.json", default={})
                for u in users:
                    if u.get("polling_station_code") == old_code:
                        u["polling_station_code"] = new_code
                if old_code in results:
                    results[new_code] = results.pop(old_code)
                    results[new_code]["polling_station_code"] = new_code
                save_json("users.json", users)
                save_json("results.json", results)
                ps_code = new_code

            save_json("polling_stations.json", stations)
            # refresh center stats
            if centers:
                centers = _recompute_center_stats(centers, stations)
                save_json("voting_centers.json", centers)
            touch_last_update()
            flash("Bureau modifié.", "success")
            return redirect(url_for("admin_polling_stations"))

        return render_template("admin_polling_station_edit.html", station=station, centers=centers)

    @app.post("/admin/polling-stations/<ps_code>/delete")
    @login_required
    @role_required("admin")
    def admin_polling_station_delete(ps_code: str):
        stations = load_json("polling_stations.json", default=[])
        if not any(s.get("code") == ps_code for s in stations):
            flash("Bureau introuvable.", "danger")
            return redirect(url_for("admin_polling_stations"))

        results = load_json("results.json", default={})
        if ps_code in results:
            flash("Suppression interdite : ce bureau a déjà un PV. Supprimez d’abord le PV.", "danger")
            return redirect(url_for("admin_polling_stations"))

        # suppression autorisée (aucun PV)
        stations = [s for s in stations if s.get("code") != ps_code]
        save_json("polling_stations.json", stations)

        # Clear assignment (un-assign automatiquement)
        users = load_json("users.json", default=[])
        for u in users:
            if u.get("polling_station_code") == ps_code:
                u["polling_station_code"] = None
        save_json("users.json", users)

        # refresh center stats
        centers = load_json("voting_centers.json", default=[])
        if centers:
            centers = _recompute_center_stats(centers, stations)
            save_json("voting_centers.json", centers)

        touch_last_update()
        flash("Bureau supprimé.", "success")
        return redirect(url_for("admin_polling_stations"))


    @app.route("/admin/users", methods=["GET", "POST"])
    @login_required
    @role_required("admin")
    def admin_users():
        users = load_json("users.json", default=[])
        stations = load_json("polling_stations.json", default=[])

        if request.method == "POST":
            role = request.form.get("role", "rep").strip()
            username = request.form.get("username", "").strip()
            password = request.form.get("password", "").strip()
            full_name = request.form.get("full_name", "").strip()
            contacts = request.form.get("contacts", "").strip()
            polling_station_code = request.form.get("polling_station_code", "").strip() or None

            if not username or not password:
                flash("Username et mot de passe requis.", "danger")
                return redirect(url_for("admin_users"))

            if any(u.get("username") == username for u in users):
                flash("Username déjà utilisé.", "danger")
                return redirect(url_for("admin_users"))

            if polling_station_code and not any(s.get("code") == polling_station_code for s in stations):
                flash("Bureau de vote invalide.", "danger")
                return redirect(url_for("admin_users"))

            users.append({
                "username": username,
                "password_hash": generate_password_hash(password),
                "role": role,
                "full_name": full_name,
                "contacts": contacts,
                "polling_station_code": polling_station_code,
                "is_active": True,
            })
            save_json("users.json", users)
            flash("Utilisateur ajouté.", "success")
            return redirect(url_for("admin_users"))

        return render_template("admin_users.html", users=users, stations=stations)

    @app.route("/admin/users/<username>/edit", methods=["GET", "POST"])
    @login_required
    @role_required("admin")
    def admin_user_edit(username: str):
        users = load_json("users.json", default=[])
        stations = load_json("polling_stations.json", default=[])
        u = next((x for x in users if x.get("username") == username), None)
        if not u:
            flash("Utilisateur introuvable.", "danger")
            return redirect(url_for("admin_users"))

        if request.method == "POST":
            role = request.form.get("role", u.get("role", "rep")).strip()
            full_name = request.form.get("full_name", "").strip()
            contacts = request.form.get("contacts", "").strip()
            polling_station_code = request.form.get("polling_station_code", "").strip() or None
            is_active = True if request.form.get("is_active") == "on" else False
            new_password = request.form.get("password", "").strip()

            if polling_station_code and not any(s.get("code") == polling_station_code for s in stations):
                flash("Bureau de vote invalide.", "danger")
                return redirect(url_for("admin_user_edit", username=username))

            # Prevent locking yourself out completely
            me = current_user()
            if me and me.get("username") == username and role != "admin":
                flash("Vous ne pouvez pas retirer votre rôle admin sur votre propre compte.", "danger")
                return redirect(url_for("admin_user_edit", username=username))

            u["role"] = role
            u["full_name"] = full_name
            u["contacts"] = contacts
            u["polling_station_code"] = polling_station_code
            u["is_active"] = is_active
            if new_password:
                u["password_hash"] = generate_password_hash(new_password)

            save_json("users.json", users)
            touch_last_update()
            flash("Utilisateur modifié.", "success")
            return redirect(url_for("admin_users"))

        return render_template("admin_user_edit.html", user=u, stations=stations)

    @app.post("/admin/users/<username>/delete")
    @login_required
    @role_required("admin")
    def admin_user_delete(username: str):
        users = load_json("users.json", default=[])
        u = next((x for x in users if x.get("username") == username), None)
        if not u:
            flash("Utilisateur introuvable.", "danger")
            return redirect(url_for("admin_users"))
        if u.get("role") == "admin":
            flash("Suppression d’un admin interdite.", "danger")
            return redirect(url_for("admin_users"))

        users = [x for x in users if x.get("username") != username]
        save_json("users.json", users)
        touch_last_update()
        flash("Utilisateur supprimé.", "success")
        return redirect(url_for("admin_users"))

    @app.route("/admin/assignments", methods=["GET", "POST"])
    @login_required
    @role_required("admin")
    def admin_assignments():
        """
        Import CSV: username,polling_station_code
        """
        if request.method == "POST":
            f = request.files.get("csv_file")
            if not f or not f.filename:
                flash("Veuillez sélectionner un fichier CSV.", "danger")
                return redirect(url_for("admin_assignments"))

            users = load_json("users.json", default=[])
            stations = load_json("polling_stations.json", default=[])
            station_codes = {s["code"] for s in stations}
            user_map = {u["username"]: u for u in users}

            decoded = f.read().decode("utf-8-sig").splitlines()
            reader = csv.DictReader(decoded)

            required = {"username", "polling_station_code"}
            if not required.issubset(set(reader.fieldnames or [])):
                flash("CSV invalide. Colonnes requises: username,polling_station_code", "danger")
                return redirect(url_for("admin_assignments"))

            updated = 0
            errors = []
            for row in reader:
                username = (row.get("username") or "").strip()
                code = (row.get("polling_station_code") or "").strip()
                if not username or not code:
                    continue
                if username not in user_map:
                    errors.append(f"Utilisateur introuvable: {username}")
                    continue
                if code not in station_codes:
                    errors.append(f"Bureau introuvable: {code}")
                    continue
                user_map[username]["polling_station_code"] = code
                updated += 1

            save_json("users.json", list(user_map.values()))
            flash(f"Affectations importées: {updated}.", "success")
            if errors:
                flash("Erreurs: " + " | ".join(errors[:10]), "warning")
            return redirect(url_for("admin_assignments"))

        return render_template("admin_assignments.html")

    @app.route("/admin/results", methods=["GET"])
    @login_required
    @role_required("admin")
    def admin_results():
        candidates = load_json("candidates.json", default=[])
        stations = load_json("polling_stations.json", default=[])
        results = load_json("results.json", default={})
        # enrich for display
        station_map = {s["code"]: s for s in stations}
        cand_map = {c["id"]: c for c in candidates}
        items = []
        for code, r in results.items():
            votes = r.get("votes") or {}
            items.append({
                "code": code,
                "station": station_map.get(code),
                "total_votes": r.get("total_votes", 0),
                "status": r.get("status"),
                "submitted_by": r.get("submitted_by"),
                "submitted_at_utc": r.get("submitted_at_utc"),
                "validated_by": r.get("validated_by"),
                "validated_at_utc": r.get("validated_at_utc"),
                "votes_human": [(cand_map.get(cid, {"name": cid})["name"], votes.get(cid, 0)) for cid in votes.keys()],
            })
        items.sort(key=lambda x: x["code"])
        return render_template("admin_results.html", items=items)

    @app.route("/admin/results/<code>/edit", methods=["GET", "POST"])
    @login_required
    @role_required("admin")
    def admin_result_edit(code: str):
        candidates = load_json("candidates.json", default=[])
        stations = load_json("polling_stations.json", default=[])
        results = load_json("results.json", default={})
        if code not in results:
            flash("PV introuvable.", "danger")
            return redirect(url_for("admin_results"))
        r = results[code]
        station = next((s for s in stations if s.get("code") == code), None)

        if request.method == "POST":
            votes: Dict[str, int] = {}
            for c in candidates:
                cid = c["id"]
                raw = request.form.get(f"votes_{cid}", "0").strip() or "0"
                try:
                    iv = int(raw)
                except Exception:
                    flash("Les voix doivent être des entiers.", "danger")
                    return redirect(url_for("admin_result_edit", code=code))
                if iv < 0:
                    flash("Les voix ne peuvent pas être négatives.", "danger")
                    return redirect(url_for("admin_result_edit", code=code))
                votes[cid] = iv

            total = sum(votes.values())

            # Control: total votes cannot exceed registered voters for this polling station
            if station:
                registered = _safe_int(station.get("registered"), default=0)
                if registered > 0 and total > registered:
                    flash(
                        f"PV invalide : total des voix ({total}) supérieur au nombre d’inscrits du bureau ({registered}).",
                        "danger",
                    )
                    return redirect(url_for("admin_result_edit", code=code))

            status = request.form.get("status", r.get("status", "SUBMITTED")).strip() or "SUBMITTED"

            r["votes"] = votes
            r["total_votes"] = total
            r["status"] = status
            if status == "VALIDATED":
                u = current_user()
                r["validated_by"] = u["username"]
                r["validated_at_utc"] = datetime.now(timezone.utc).isoformat()
            else:
                r["validated_by"] = None
                r["validated_at_utc"] = None

            results[code] = r
            save_json("results.json", results)
            touch_last_update()
            flash("PV modifié.", "success")
            return redirect(url_for("admin_results"))

        return render_template("admin_result_edit.html", code=code, station=station, cand=candidates, pv=r)

    @app.post("/admin/results/<code>/delete")
    @login_required
    @role_required("admin")
    def admin_result_delete(code: str):
        results = load_json("results.json", default={})
        if code not in results:
            flash("PV introuvable.", "danger")
            return redirect(url_for("admin_results"))
        results.pop(code, None)
        save_json("results.json", results)
        touch_last_update()
        flash("PV supprimé.", "success")
        return redirect(url_for("admin_results"))

    @app.post("/admin/results/<code>/validate")
    @login_required
    @role_required("admin")
    def admin_validate_result(code: str):
        results = load_json("results.json", default={})
        if code not in results:
            flash("Résultat introuvable.", "danger")
            return redirect(url_for("admin_results"))

        # Safety control: do not validate if total votes exceed registered voters
        stations = load_json("polling_stations.json", default=[])
        station = next((s for s in stations if s.get("code") == code), None)
        if station:
            registered = _safe_int(station.get("registered"), default=0)
            total = int(results[code].get("total_votes") or 0)
            if registered > 0 and total > registered:
                flash(
                    f"Validation refusée : total des voix ({total}) supérieur au nombre d’inscrits ({registered}).",
                    "danger",
                )
                return redirect(url_for("admin_results"))

        u = current_user()
        results[code]["status"] = "VALIDATED"
        results[code]["validated_by"] = u["username"]
        results[code]["validated_at_utc"] = datetime.now(timezone.utc).isoformat()
        save_json("results.json", results)
        touch_last_update()
        flash(f"Résultat validé: {code}", "success")
        return redirect(url_for("admin_results"))

    return app

# -------------------------
# Helpers / seed data
# -------------------------
def _next_id(existing_ids, prefix="C"):
    nums = []
    for x in existing_ids:
        if isinstance(x, str) and x.startswith(prefix):
            try:
                nums.append(int(x[len(prefix):]))
            except Exception:
                pass
    n = max(nums) + 1 if nums else 1
    return f"{prefix}{n:03d}"


def _safe_int(val, default: int = 0) -> int:
    """Parse an int coming from forms/CSV. Accepts spaces and commas."""
    if val is None:
        return default
    try:
        s = str(val).strip().replace(" ", "").replace(",", "")
        if s == "":
            return default
        return int(s)
    except Exception:
        return default


def _recompute_center_stats(centers, stations):
    """Recompute nb_bureaux and registered_total for each center based on stations."""
    if not isinstance(centers, list):
        return centers
    if not isinstance(stations, list):
        stations = []

    counts = {}
    totals = {}
    for s in stations:
        cc = (s.get("centre_code") or "").strip().zfill(3)
        if not cc:
            continue
        counts[cc] = counts.get(cc, 0) + 1
        totals[cc] = totals.get(cc, 0) + int(s.get("registered") or 0)

    out = []
    for c in centers:
        code = (c.get("code") or "").strip().zfill(3)
        if not code:
            continue
        c["code"] = code
        c["nb_bureaux"] = int(counts.get(code, 0))
        c["registered_total"] = int(totals.get(code, 0))
        if not c.get("commune"):
            c["commune"] = "BONOUA"
        out.append(c)
    out.sort(key=lambda x: x.get("code"))
    return out

def _ensure_seed_data():
    # Election meta
    election_path = DATA_DIR / "election.json"
    if not election_path.exists():
        save_json("election.json", {
            "name": "Municipales – Bonoua",
            "year": 2028,
            "round": 1,
            "commune": "Bonoua",
            "status": "OPEN",
        })

    # Candidates seed
    cand_path = DATA_DIR / "candidates.json"
    if not cand_path.exists():
        save_json("candidates.json", [
            {"id": "C001", "name": "Candidat 1", "party": "Parti A", "photo": ""},
            {"id": "C002", "name": "Candidat 2", "party": "Parti B", "photo": ""},
            {"id": "C003", "name": "Candidat 3", "party": "Parti C", "photo": ""},
            {"id": "C004", "name": "Candidat 4", "party": "Indépendant", "photo": ""},
        ])

    # Polling stations seed (Bonoua sample)
    ps_path = DATA_DIR / "polling_stations.json"
    if not ps_path.exists():
        save_json("polling_stations.json", [
            {"code": "BON-EPP-MUNI-01", "name": "EPP Municipalité – Bureau 1", "quartier": "Centre"},
            {"code": "BON-EPP-MUNI-02", "name": "EPP Municipalité – Bureau 2", "quartier": "Centre"},
        ])

    # Users seed
    users_path = DATA_DIR / "users.json"
    if not users_path.exists():
        save_json("users.json", [
            {
                "username": "admin",
                "password_hash": generate_password_hash("Admin123!"),
                "role": "admin",
                "full_name": "Administrateur",
                "contacts": "",
                "polling_station_code": None,
                "is_active": True,
            },
            {
                "username": "rep1",
                "password_hash": generate_password_hash("Rep123!"),
                "role": "rep",
                "full_name": "Représentant 1",
                "contacts": "",
                "polling_station_code": "BON-EPP-MUNI-01",
                "is_active": True,
            },
            {
                "username": "rep2",
                "password_hash": generate_password_hash("Rep123!"),
                "role": "rep",
                "full_name": "Représentant 2",
                "contacts": "",
                "polling_station_code": "BON-EPP-MUNI-02",
                "is_active": True,
            },
        ])

    # Results seed
    res_path = DATA_DIR / "results.json"
    if not res_path.exists():
        save_json("results.json", {})

    meta_path = DATA_DIR / "meta.json"
    if not meta_path.exists():
        save_json("meta.json", {"last_update_utc": None})
