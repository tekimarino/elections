from functools import wraps
from flask import session, redirect, url_for, flash, request
from werkzeug.security import check_password_hash
from .storage import load_json

def get_user(username: str):
    users = load_json("users.json", default=[])
    for u in users:
        if u.get("username") == username:
            return u
    return None

def current_user():
    username = session.get("username")
    if not username:
        return None
    return get_user(username)

def authenticate(username: str, password: str):
    u = get_user(username)
    if not u or not u.get("is_active", True):
        return None
    if check_password_hash(u.get("password_hash", ""), password):
        return u
    return None

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not session.get("username"):
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped

def role_required(*roles):
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            u = current_user()
            if not u:
                return redirect(url_for("login", next=request.path))
            if u.get("role") not in roles:
                flash("Accès refusé.", "danger")
                return redirect(url_for("index"))
            return view(*args, **kwargs)
        return wrapped
    return decorator
